import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { Language, Theme, User, PrayerTimes, LocationInfo, LastRead, FavoriteVerse, ActiveAdhan, StreakData } from '../types';
import { TRANSLATIONS, ADHANS, RECITERS, DEFAULT_ADHKAR } from '../constants';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  user: User | null;
  login: () => void;
  logout: () => void;
  updateProfile: (displayName: string, photoURL: string) => void;
  t: (key: string) => string;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  
  // Prayer Times State
  prayerTimes: PrayerTimes | null;
  location: LocationInfo;
  nextPrayerName: string;
  countdown: string;
  updateLocation: (city: string, country: string) => Promise<boolean>;

  // Quran State
  lastRead: LastRead | null;
  setLastRead: (read: LastRead) => void;
  favoriteVerses: FavoriteVerse[];
  toggleFavoriteVerse: (verse: FavoriteVerse) => void;
  quranAyahsReadToday: number;
  incrementQuranAyahsRead: () => void;

  // Preferences
  selectedAdhan: string;
  setSelectedAdhan: (id: string) => void;
  selectedReciter: string;
  setSelectedReciter: (id: string) => void;
  notificationsEnabled: boolean;
  requestNotificationPermission: () => void;

  // Active Adhan
  activeAdhan: ActiveAdhan | null;
  setActiveAdhan: (adhan: ActiveAdhan | null) => void;

  // Streak
  streakData: StreakData;
  resetStreak: () => void;

  // Adhkar Notifications
  adhkarNotifications: string[];
  toggleAdhkarNotification: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_STREAK: StreakData = { current: 0, longest: 0, points: 0, lastActiveDate: '' };

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('en');
  const [theme, setThemeState] = useState<Theme>('light');
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Prayer Times State
  const [prayerTimes, setPrayerTimes] = useState<PrayerTimes | null>(null);
  const [location, setLocation] = useState<LocationInfo>({ city: 'Loading...', country: '' });
  const [nextPrayerName, setNextPrayerName] = useState<string>('...');
  const [nextPrayerTime, setNextPrayerTime] = useState<Date | null>(null);
  const [countdown, setCountdown] = useState<string>('00:00:00');

  // Quran State
  const [lastRead, setLastReadState] = useState<LastRead | null>(null);
  const [favoriteVerses, setFavoriteVersesState] = useState<FavoriteVerse[]>([]);
  const [quranAyahsReadToday, setQuranAyahsReadToday] = useState(0);

  // Preferences
  const [selectedAdhan, setSelectedAdhanState] = useState<string>(ADHANS[0].id);
  const [selectedReciter, setSelectedReciterState] = useState<string>(RECITERS[0].id);
  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(false);
  const [notifiedPrayers, setNotifiedPrayers] = useState<Record<string, string>>({});

  // Active Adhan
  const [activeAdhan, setActiveAdhan] = useState<ActiveAdhan | null>(null);

  // Streak
  const [streakData, setStreakDataState] = useState<StreakData>(DEFAULT_STREAK);

  // Adhkar Notifications
  const [adhkarNotifications, setAdhkarNotificationsState] = useState<string[]>([]);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
  }, []);

  const setTheme = useCallback((newTheme: Theme) => {
    setThemeState(newTheme);
  }, []);

  const updateLocation = async (city: string, country: string): Promise<boolean> => {
    try {
      const res = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}`);
      const data = await res.json();
      if (data.data && data.data.timings) {
        setPrayerTimes(data.data.timings);
        const newLoc = { city, country };
        setLocation(newLoc);
        localStorage.setItem('muslim_manual_location', JSON.stringify(newLoc));
        return true;
      }
      return false;
    } catch (err) {
      console.error("Error updating location manually:", err);
      return false;
    }
  };

  useEffect(() => {
    // Load saved preferences
    const savedLang = localStorage.getItem('muslim_lang') as Language;
    if (savedLang) setLanguageState(savedLang);

    const savedTheme = localStorage.getItem('muslim_theme') as Theme;
    if (savedTheme) {
      setThemeState(savedTheme);
    } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setThemeState('dark');
    }

    const savedAdhan = localStorage.getItem('muslim_adhan');
    if (savedAdhan) setSelectedAdhanState(savedAdhan);

    const savedReciter = localStorage.getItem('muslim_reciter');
    if (savedReciter) setSelectedReciterState(savedReciter);

    const savedAdhkarNotifs = localStorage.getItem('muslim_adhkar_notifs');
    if (savedAdhkarNotifs) setAdhkarNotificationsState(JSON.parse(savedAdhkarNotifs));

    if ('Notification' in window) {
      setNotificationsEnabled(Notification.permission === 'granted');
    }

    const today = new Date().toDateString();
    const savedQuranRead = localStorage.getItem(`muslim_quran_read_${today}`);
    if (savedQuranRead) setQuranAyahsReadToday(parseInt(savedQuranRead, 10));

    const savedUser = localStorage.getItem('muslim_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      const savedLastRead = localStorage.getItem(`muslim_last_read_${parsedUser.uid}`);
      if (savedLastRead) setLastReadState(JSON.parse(savedLastRead));
      
      const savedFavs = localStorage.getItem(`muslim_fav_verses_${parsedUser.uid}`);
      if (savedFavs) setFavoriteVersesState(JSON.parse(savedFavs));

      const savedStreak = localStorage.getItem(`muslim_streak_${parsedUser.uid}`);
      if (savedStreak) setStreakDataState(JSON.parse(savedStreak));
    }

    // Fetch Location and Prayer Times
    const fetchPrayerDataByCoords = (lat: number, lon: number) => {
      fetch(`https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lon}`)
        .then(res => res.json())
        .then(data => {
          if (data.data && data.data.timings) {
            setPrayerTimes(data.data.timings);
          }
        })
        .catch(err => console.error("Error fetching prayer times:", err));

      fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=en`)
        .then(res => res.json())
        .then(data => {
          setLocation({
            city: data.city || data.locality || 'Unknown City',
            country: data.countryName || 'Unknown Country'
          });
        })
        .catch(err => console.error("Error fetching location:", err));
    };

    const savedLoc = localStorage.getItem('muslim_manual_location');
    if (savedLoc) {
      const { city, country } = JSON.parse(savedLoc);
      updateLocation(city, country);
    } else if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          fetchPrayerDataByCoords(position.coords.latitude, position.coords.longitude);
        },
        (error) => {
          console.error("Geolocation error", error);
          updateLocation('Makkah', 'Saudi Arabia');
        }
      );
    } else {
      updateLocation('Makkah', 'Saudi Arabia');
    }

    setTimeout(() => setIsLoading(false), 2500);
  }, []);

  // Calculate Next Prayer and Countdown
  useEffect(() => {
    if (!prayerTimes) return;

    const calculateNextPrayer = () => {
      const now = new Date();
      const prayers = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
      let nextPName = '';
      let nextPTime: Date | null = null;
      let minDiff = Infinity;

      for (const p of prayers) {
        const timeStr = prayerTimes[p as keyof PrayerTimes];
        if (!timeStr) continue;
        
        const [hours, minutes] = timeStr.split(':').map(Number);
        const pTime = new Date();
        pTime.setHours(hours, minutes, 0, 0);

        const diff = pTime.getTime() - now.getTime();
        if (diff > 0 && diff < minDiff) {
          minDiff = diff;
          nextPName = p;
          nextPTime = pTime;
        }
      }

      if (!nextPTime) {
        const timeStr = prayerTimes['Fajr'];
        if (timeStr) {
          const [hours, minutes] = timeStr.split(':').map(Number);
          nextPTime = new Date();
          nextPTime.setDate(nextPTime.getDate() + 1);
          nextPTime.setHours(hours, minutes, 0, 0);
          nextPName = 'Fajr';
        }
      }

      if (nextPName !== nextPrayerName) setNextPrayerName(nextPName);
      setNextPrayerTime(nextPTime);
    };

    calculateNextPrayer();
    const interval = setInterval(calculateNextPrayer, 60000);
    return () => clearInterval(interval);
  }, [prayerTimes]);

  // Update Countdown every second
  useEffect(() => {
    if (!nextPrayerTime) return;

    const updateCountdown = () => {
      const now = new Date();
      let diff = nextPrayerTime.getTime() - now.getTime();
      
      if (diff < 0) {
        setCountdown('00:00:00');
        return;
      }

      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);

      setCountdown(
        `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
      );
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [nextPrayerTime]);

  // Prayer Notifications & Adhan Screen
  useEffect(() => {
    if (!prayerTimes) return;

    const interval = setInterval(() => {
      const now = new Date();
      const todayStr = now.toDateString();
      const currentTimeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

      Object.entries(prayerTimes).forEach(([prayer, time]) => {
        if (['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].includes(prayer)) {
          if (time === currentTimeStr && notifiedPrayers[prayer] !== todayStr) {
            
            // Trigger Adhan Screen
            const adhanObj = ADHANS.find(a => a.id === selectedAdhan) || ADHANS[0];
            setActiveAdhan({ prayer, url: adhanObj.url });
            
            if (notificationsEnabled && Notification.permission === 'granted') {
              // Use Service Worker registration to show notification if possible (works better in background)
              if ('serviceWorker' in navigator) {
                navigator.serviceWorker.ready.then(registration => {
                  registration.showNotification(`Time for ${prayer}`, {
                    body: `It is now time for ${prayer} prayer.`,
                    icon: 'https://cdn-icons-png.flaticon.com/512/1034/1034131.png',
                    vibrate: [200, 100, 200, 100, 200, 100, 200],
                    requireInteraction: true,
                    tag: 'prayer-time'
                  });
                }).catch(() => {
                  // Fallback to standard notification
                  new Notification(`Time for ${prayer}`, {
                    body: `It is now time for ${prayer} prayer.`,
                    requireInteraction: true
                  });
                });
              } else {
                new Notification(`Time for ${prayer}`, {
                  body: `It is now time for ${prayer} prayer.`,
                  requireInteraction: true
                });
              }
            }
            
            setNotifiedPrayers(prev => ({ ...prev, [prayer]: todayStr }));
          }
        }
      });
    }, 60000);

    return () => clearInterval(interval);
  }, [prayerTimes, notifiedPrayers, notificationsEnabled, selectedAdhan]);

  // Adhkar Periodic Notifications
  useEffect(() => {
    if (!notificationsEnabled || adhkarNotifications.length === 0) return;
    
    const interval = setInterval(() => {
      if (Notification.permission === 'granted') {
        const randomId = adhkarNotifications[Math.floor(Math.random() * adhkarNotifications.length)];
        const allAdhkar = JSON.parse(localStorage.getItem('muslim_adhkar_list') || '[]');
        const adhkar = allAdhkar.find((a: any) => a.id === randomId) || DEFAULT_ADHKAR.find(a => a.id === randomId);
        
        if (adhkar) {
          if ('serviceWorker' in navigator) {
            navigator.serviceWorker.ready.then(registration => {
              registration.showNotification('Daily Adhkar Reminder', { 
                body: adhkar.arabic,
                icon: 'https://cdn-icons-png.flaticon.com/512/1034/1034131.png',
                tag: 'adhkar-reminder'
              });
            });
          } else {
            new Notification('Daily Adhkar Reminder', { 
              body: adhkar.arabic,
              icon: 'https://cdn-icons-png.flaticon.com/512/1034/1034131.png'
            });
          }
        }
      }
    }, 15 * 60 * 1000); // Every 15 minutes for demo purposes

    return () => clearInterval(interval);
  }, [notificationsEnabled, adhkarNotifications]);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('muslim_theme', theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
    localStorage.setItem('muslim_lang', language);
  }, [language]);

  const setSelectedAdhan = (id: string) => {
    setSelectedAdhanState(id);
    localStorage.setItem('muslim_adhan', id);
  };

  const setSelectedReciter = (id: string) => {
    setSelectedReciterState(id);
    localStorage.setItem('muslim_reciter', id);
  };

  const requestNotificationPermission = () => {
    if ('Notification' in window) {
      Notification.requestPermission().then(permission => {
        setNotificationsEnabled(permission === 'granted');
      });
    }
  };

  const setLastRead = (read: LastRead) => {
    if (user) {
      setLastReadState(read);
      localStorage.setItem(`muslim_last_read_${user.uid}`, JSON.stringify(read));
    }
  };

  const toggleFavoriteVerse = (verse: FavoriteVerse) => {
    if (user) {
      setFavoriteVersesState(prev => {
        const exists = prev.find(v => v.id === verse.id);
        let newFavs;
        if (exists) {
          newFavs = prev.filter(v => v.id !== verse.id);
        } else {
          newFavs = [...prev, verse];
        }
        localStorage.setItem(`muslim_fav_verses_${user.uid}`, JSON.stringify(newFavs));
        return newFavs;
      });
    }
  };

  const toggleAdhkarNotification = (id: string) => {
    setAdhkarNotificationsState(prev => {
      const newSet = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      localStorage.setItem('muslim_adhkar_notifs', JSON.stringify(newSet));
      return newSet;
    });
  };

  const incrementQuranAyahsRead = useCallback(() => {
    setQuranAyahsReadToday(prev => {
      const newVal = prev + 1;
      const today = new Date().toDateString();
      localStorage.setItem(`muslim_quran_read_${today}`, newVal.toString());
      return newVal;
    });
  }, []);

  const resetStreak = useCallback(() => {
    setStreakDataState(DEFAULT_STREAK);
    if (user) {
      localStorage.setItem(`muslim_streak_${user.uid}`, JSON.stringify(DEFAULT_STREAK));
    }
  }, [user]);

  const login = () => {
    const mockUser: User = {
      uid: '12345',
      displayName: 'AB1 Studio',
      email: 'abayobihqt@gmail.com',
      photoURL: 'https://picsum.photos/200',
      memberSince: new Date().toISOString(),
    };
    setUser(mockUser);
    localStorage.setItem('muslim_user', JSON.stringify(mockUser));
    
    const savedLastRead = localStorage.getItem(`muslim_last_read_${mockUser.uid}`);
    if (savedLastRead) setLastReadState(JSON.parse(savedLastRead));
    
    const savedFavs = localStorage.getItem(`muslim_fav_verses_${mockUser.uid}`);
    if (savedFavs) setFavoriteVersesState(JSON.parse(savedFavs));

    const savedStreak = localStorage.getItem(`muslim_streak_${mockUser.uid}`);
    if (savedStreak) setStreakDataState(JSON.parse(savedStreak));
    else setStreakDataState(DEFAULT_STREAK);
  };

  const logout = () => {
    setUser(null);
    setLastReadState(null);
    setFavoriteVersesState([]);
    setStreakDataState(DEFAULT_STREAK);
    localStorage.removeItem('muslim_user');
  };

  const updateProfile = (displayName: string, photoURL: string) => {
    if (user) {
      const updatedUser = { ...user, displayName, photoURL };
      setUser(updatedUser);
      localStorage.setItem('muslim_user', JSON.stringify(updatedUser));
    }
  };

  const t = useCallback((key: string): string => {
    return TRANSLATIONS[key]?.[language] || key;
  }, [language]);

  return (
    <AppContext.Provider value={{ 
      language, setLanguage, theme, setTheme, user, login, logout, updateProfile, t, isLoading, setIsLoading,
      prayerTimes, location, nextPrayerName, countdown, updateLocation,
      lastRead, setLastRead, favoriteVerses, toggleFavoriteVerse,
      quranAyahsReadToday, incrementQuranAyahsRead,
      selectedAdhan, setSelectedAdhan, selectedReciter, setSelectedReciter,
      notificationsEnabled, requestNotificationPermission,
      activeAdhan, setActiveAdhan,
      streakData, resetStreak,
      adhkarNotifications, toggleAdhkarNotification
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
