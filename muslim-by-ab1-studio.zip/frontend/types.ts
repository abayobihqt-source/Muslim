export type Language = 'en' | 'ar';
export type Theme = 'light' | 'dark';

export interface User {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  memberSince: string;
}

export interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

export interface Ayah {
  number: number;
  text: string;
  numberInSurah: number;
  juz: number;
  manzil: number;
  page: number;
  ruku: number;
  hizbQuarter: number;
  sajda: boolean | object;
  audio?: string;
  translation?: string;
}

export interface PrayerTimes {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
}

export interface LocationInfo {
  city: string;
  country: string;
}

export interface AdhkarCategory {
  id: string;
  iconName: string;
  label: string;
  color: string;
  bg: string;
}

export interface AdhkarItem {
  id: string;
  category: string;
  arabic: string;
  translation: string;
  transliteration?: string;
  count: number;
  currentCount: number;
}

export interface LastRead {
  surahNumber: number;
  surahName: string;
  ayahNumber: number;
}

export interface FavoriteVerse {
  id: string;
  surahNumber: number;
  surahName: string;
  ayahNumber: number;
  text: string;
}

export interface Translations {
  [key: string]: {
    en: string;
    ar: string;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface ActiveAdhan {
  prayer: string;
  url: string;
}

export interface StreakData {
  current: number;
  longest: number;
  points: number;
  lastActiveDate: string;
}
