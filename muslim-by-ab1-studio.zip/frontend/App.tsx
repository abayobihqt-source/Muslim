import React, { useState, useEffect, useRef } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Layout from './components/Layout';
import LoadingScreen from './components/LoadingScreen';
import Home from './pages/Home';
import Quran from './pages/Quran';
import PrayerTimes from './pages/PrayerTimes';
import Adhkar from './pages/Adhkar';
import Gallery from './pages/Gallery';
import Profile from './pages/Profile';
import Assistant from './pages/Assistant';
import { Volume2, X, Play } from 'lucide-react';

const AdhanScreen: React.FC = () => {
  const { activeAdhan, setActiveAdhan, t, language } = useApp();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [autoplayBlocked, setAutoplayBlocked] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!activeAdhan) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
      setAutoplayBlocked(false);
      return;
    }

    // Create and play audio
    audioRef.current = new Audio(activeAdhan.url);
    
    // Attempt to play
    const playPromise = audioRef.current.play();
    
    if (playPromise !== undefined) {
      playPromise.catch(error => {
        console.error("Adhan play blocked by browser policy. User interaction required.", error);
        setAutoplayBlocked(true);
      });
    }
    
    audioRef.current.onended = () => setActiveAdhan(null);
    
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
    };
  }, [activeAdhan, setActiveAdhan]);

  const handleManualPlay = () => {
    if (audioRef.current) {
      audioRef.current.play();
      setAutoplayBlocked(false);
    }
  };

  if (!activeAdhan) return null;

  const timeString = currentTime.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center overflow-hidden bg-[#022c22]">
      {/* Islamic Pattern Background */}
      <div className="absolute inset-0 opacity-30 bg-[url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23fbbf24\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]"></div>
      
      {/* Makkah Background Image with Blend */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat mix-blend-overlay opacity-60"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1565552645632-d725e8bfc19a?q=80&w=2070&auto=format&fit=crop')" }}
      ></div>
      
      {/* Dark Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#022c22] via-transparent to-[#022c22] opacity-90"></div>

      <div className="relative z-10 flex flex-col items-center text-center p-8 w-full max-w-md">
        {/* Decorative Top Element */}
        <div className="mb-8 flex justify-center w-full">
          <svg width="120" height="40" viewBox="0 0 120 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M60 0L120 40H0L60 0Z" fill="url(#paint0_linear)" opacity="0.3"/>
            <path d="M60 10L100 40H20L60 10Z" fill="#FBBF24"/>
            <defs>
              <linearGradient id="paint0_linear" x1="60" y1="0" x2="60" y2="40" gradientUnits="userSpaceOnUse">
                <stop stopColor="#FBBF24"/>
                <stop offset="1" stopColor="#FBBF24" stopOpacity="0"/>
              </linearGradient>
            </defs>
          </svg>
        </div>

        <div className="w-32 h-32 mb-8 rounded-full bg-gold-500/20 flex items-center justify-center animate-pulse border-2 border-gold-400/50 shadow-[0_0_40px_rgba(251,191,36,0.4)]">
          <Volume2 size={64} className="text-gold-400" />
        </div>
        
        <h2 className="text-2xl text-gold-400 mb-2 font-medium tracking-widest uppercase">{t('prayerTimes')}</h2>
        <h1 className="text-7xl font-bold mb-4 text-white drop-shadow-lg">{t(activeAdhan.prayer)}</h1>
        
        <div className="text-4xl font-mono font-light text-white/90 mb-12 tracking-wider">
          {timeString}
        </div>

        {autoplayBlocked && (
          <button 
            onClick={handleManualPlay}
            className="mb-6 flex items-center gap-2 bg-gold-500 hover:bg-gold-400 text-amber-950 px-8 py-4 rounded-full font-bold text-lg transition-all shadow-lg animate-bounce"
          >
            <Play size={24} />
            Tap to Play Adhan
          </button>
        )}

        <button 
          onClick={() => setActiveAdhan(null)}
          className="group flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/30 text-white px-8 py-4 rounded-full font-bold text-lg transition-all backdrop-blur-md"
        >
          <X size={24} className="group-hover:rotate-90 transition-transform" />
          Dismiss
        </button>
      </div>
    </div>
  );
};

const AppContent: React.FC = () => {
  const { isLoading } = useApp();
  const [currentPage, setCurrentPage] = useState('home');

  if (isLoading) {
    return <LoadingScreen />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <Home navigateTo={setCurrentPage} />;
      case 'quran': return <Quran />;
      case 'prayer': return <PrayerTimes />;
      case 'adhkar': return <Adhkar />;
      case 'gallery': return <Gallery />;
      case 'assistant': return <Assistant />;
      case 'profile': return <Profile />;
      default: return <Home navigateTo={setCurrentPage} />;
    }
  };

  return (
    <>
      <Layout currentPage={currentPage} setCurrentPage={setCurrentPage}>
        {renderPage()}
      </Layout>
      <AdhanScreen />
    </>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
};

export default App;
