import React, { useState, useEffect } from 'react';
import { BookOpen, Sunrise, Sunset, Heart, ArrowRight, Timer, MessageSquareText } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../constants';

const Home: React.FC<{ navigateTo: (page: string) => void }> = ({ navigateTo }) => {
  const { language, nextPrayerName, countdown, t } = useApp();
  
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const gregorianDate = new Intl.DateTimeFormat(language === 'ar' ? 'ar-SA' : 'en-US', { dateStyle: 'full' }).format(currentTime);
  
  // Calculate Hijri Date properly
  const hijriDate = new Intl.DateTimeFormat(language === 'ar' ? 'ar-SA-u-ca-islamic' : 'en-US-u-ca-islamic', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(currentTime);

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-islamic-700 to-islamic-900 text-white shadow-xl">
        <div className="absolute inset-0 opacity-20 bg-[url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]"></div>
        
        <div className="relative p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex-1 space-y-4 text-center md:text-start">
            <div className="inline-block px-4 py-1 rounded-full bg-white/20 backdrop-blur-sm text-sm font-medium mb-2">
              {hijriDate} • {gregorianDate}
            </div>
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">
              {language === 'ar' ? 'السلام عليكم' : 'As-salamu alaykum'}
            </h1>
            <p className="text-islamic-100 text-lg max-w-xl">
              {language === 'ar' 
                ? 'ابدأ يومك بذكر الله وتلاوة القرآن الكريم.' 
                : 'Start your day with the remembrance of Allah and the recitation of the Holy Quran.'}
            </p>
            <button 
              onClick={() => navigateTo('quran')}
              className="mt-4 inline-flex items-center gap-2 bg-gold-500 hover:bg-gold-400 text-amber-950 px-6 py-3 rounded-full font-semibold transition-colors"
            >
              <BookOpen size={20} />
              {t('continueReading')}
            </button>
          </div>

          {/* Next Prayer Card */}
          <div className="glass rounded-2xl p-6 w-full md:w-80 text-center border-white/20">
            <h3 className="text-islamic-100 font-medium mb-1">{t('nextPrayer')}</h3>
            <div className="text-3xl font-bold mb-4">{t(nextPrayerName)}</div>
            <div className="text-4xl font-mono font-light tracking-wider mb-2">{countdown}</div>
            <p className="text-sm text-islamic-200">{t('remaining')}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Verse of the Day */}
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 shadow-sm border border-slate-100 dark:border-slate-700 relative overflow-hidden group">
          <div className="absolute top-0 end-0 p-6 opacity-5 text-islamic-600 group-hover:scale-110 transition-transform duration-500">
            <BookOpen size={120} />
          </div>
          <h3 className="text-islamic-600 dark:text-islamic-400 font-semibold mb-4 flex items-center gap-2">
            <BookOpen size={20} /> {t('verseOfDay')}
          </h3>
          <p className="font-arabic text-2xl md:text-3xl leading-loose text-slate-800 dark:text-slate-100 mb-6 text-center" dir="rtl">
            "إِنَّ مَعَ الْعُسْرِ يُسْرًا"
          </p>
          <p className="text-slate-600 dark:text-slate-400 italic mb-4">
            "Indeed, with hardship [will be] ease."
          </p>
          <p className="text-sm text-slate-500 font-medium">Surah Ash-Sharh [94:6]</p>
        </div>

        {/* Hadith of the Day */}
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 shadow-sm border border-slate-100 dark:border-slate-700 relative overflow-hidden group">
           <div className="absolute top-0 end-0 p-6 opacity-5 text-islamic-600 group-hover:scale-110 transition-transform duration-500">
            <Heart size={120} />
          </div>
          <h3 className="text-islamic-600 dark:text-islamic-400 font-semibold mb-4 flex items-center gap-2">
            <Heart size={20} /> {t('hadithOfDay')}
          </h3>
          <p className="font-arabic text-xl md:text-2xl leading-relaxed text-slate-800 dark:text-slate-100 mb-6 text-center" dir="rtl">
            "خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ"
          </p>
          <p className="text-slate-600 dark:text-slate-400 italic mb-4">
            "The best among you (Muslims) are those who learn the Qur'an and teach it."
          </p>
          <p className="text-sm text-slate-500 font-medium">Sahih al-Bukhari 5027</p>
        </div>
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { icon: Sunrise, label: t('morningAdhkar'), color: 'bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400', action: () => navigateTo('adhkar') },
          { icon: Sunset, label: t('eveningAdhkar'), color: 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400', action: () => navigateTo('adhkar') },
          { icon: BookOpen, label: t('quran'), color: 'bg-islamic-100 text-islamic-600 dark:bg-islamic-900/30 dark:text-islamic-400', action: () => navigateTo('quran') },
          { icon: Timer, label: t('prayerTimes'), color: 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400', action: () => navigateTo('prayer') },
          { icon: MessageSquareText, label: t('assistant'), color: 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400', action: () => navigateTo('assistant') },
        ].map((item, idx) => (
          <button 
            key={idx}
            onClick={item.action}
            className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center gap-3 hover:shadow-md transition-all hover:-translate-y-1"
          >
            <div className={`p-3 rounded-full ${item.color}`}>
              <item.icon size={24} />
            </div>
            <span className="font-medium text-sm text-slate-700 dark:text-slate-200 text-center">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Home;
