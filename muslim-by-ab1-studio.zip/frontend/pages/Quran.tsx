import React, { useState, useEffect, useRef } from 'react';
import { Search, Play, Pause, SkipBack, SkipForward, Settings, X, Heart, ChevronRight, ChevronLeft } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS, RECITERS } from '../constants';
import { Surah, Ayah } from '../types';

const Quran: React.FC = () => {
  const { language, user, setLastRead, favoriteVerses, toggleFavoriteVerse, selectedReciter, setSelectedReciter, incrementQuranAyahsRead } = useApp();
  const t = (key: string) => TRANSLATIONS[key]?.[language] || key;

  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [ayahs, setAyahs] = useState<Ayah[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Audio State
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentAyahIndex, setCurrentAyahIndex] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Settings State
  const [showSettings, setShowSettings] = useState(false);
  const [fontSize, setFontSize] = useState(36);
  const [readingTheme, setReadingTheme] = useState<'default' | 'sepia' | 'islamic' | 'midnight' | 'emerald' | 'sand'>('default');

  useEffect(() => {
    fetch('https://api.alquran.cloud/v1/surah')
      .then(res => res.json())
      .then(data => setSurahs(data.data))
      .catch(err => console.error("Failed to fetch surahs", err));
  }, []);

  const loadSurah = async (surah: Surah, startAyahIndex: number = 0) => {
    setLoading(true);
    setSelectedSurah(surah);
    try {
      const arRes = await fetch(`https://api.alquran.cloud/v1/surah/${surah.number}/${selectedReciter}`);
      const arData = await arRes.json();
      
      setAyahs(arData.data.ayahs);
      setCurrentAyahIndex(startAyahIndex);
      setIsPlaying(false);
      if (audioRef.current) {
        audioRef.current.pause();
      }
    } catch (error) {
      console.error("Failed to load surah details", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedSurah) {
      loadSurah(selectedSurah, currentAyahIndex);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedReciter]);

  // Track Last Read
  useEffect(() => {
    if (selectedSurah && ayahs.length > 0 && user) {
      setLastRead({
        surahNumber: selectedSurah.number,
        surahName: language === 'ar' ? selectedSurah.name : selectedSurah.englishName,
        ayahNumber: ayahs[currentAyahIndex].numberInSurah
      });
    }
  }, [currentAyahIndex, selectedSurah, ayahs, user, language, setLastRead]);

  const filteredSurahs = surahs.filter(s => 
    s.englishName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.name.includes(searchQuery)
  );

  // Audio Controls
  useEffect(() => {
    if (isPlaying && ayahs.length > 0) {
      const audioUrl = ayahs[currentAyahIndex].audio;
      if (audioUrl) {
        if (!audioRef.current) {
          audioRef.current = new Audio(audioUrl);
        } else {
          audioRef.current.src = audioUrl;
        }
        
        audioRef.current.play().catch(e => console.error("Audio play failed", e));
        
        audioRef.current.onended = () => {
          incrementQuranAyahsRead();
          if (currentAyahIndex < ayahs.length - 1) {
            setCurrentAyahIndex(prev => prev + 1);
          } else {
            setIsPlaying(false);
          }
        };
      }
    } else if (audioRef.current) {
      audioRef.current.pause();
    }
    
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, [isPlaying, currentAyahIndex, ayahs, incrementQuranAyahsRead]);

  const togglePlay = () => setIsPlaying(!isPlaying);
  const nextAyah = () => {
    if (currentAyahIndex < ayahs.length - 1) {
      setCurrentAyahIndex(prev => prev + 1);
    }
  };
  const prevAyah = () => {
    if (currentAyahIndex > 0) {
      setCurrentAyahIndex(prev => prev - 1);
    }
  };

  const handleVerseClick = (index: number) => {
    setCurrentAyahIndex(index);
    setIsPlaying(true);
    incrementQuranAyahsRead();
  };

  const handleFavoriteClick = (e: React.MouseEvent, ayah: Ayah) => {
    e.stopPropagation();
    if (!user) {
      alert("Please sign in to save favorite verses.");
      return;
    }
    if (selectedSurah) {
      toggleFavoriteVerse({
        id: `${selectedSurah.number}_${ayah.numberInSurah}`,
        surahNumber: selectedSurah.number,
        surahName: language === 'ar' ? selectedSurah.name : selectedSurah.englishName,
        ayahNumber: ayah.numberInSurah,
        text: ayah.text
      });
    }
  };

  const navigateSurah = (direction: number) => {
    if (!selectedSurah) return;
    const nextNumber = selectedSurah.number + direction;
    const nextSurah = surahs.find(s => s.number === nextNumber);
    if (nextSurah) {
      loadSurah(nextSurah);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const getThemeClasses = () => {
    switch (readingTheme) {
      case 'sepia':
        return 'bg-[#fdf6e3] border-[#e6d5b8] text-[#4a3c24]';
      case 'islamic':
        return 'bg-[#ecfdf5] border-[#059669] text-[#064e3b] shadow-[0_0_40px_rgba(16,185,129,0.15)] relative overflow-hidden';
      case 'midnight':
        return 'bg-[#0f172a] border-[#1e293b] text-[#e2e8f0] shadow-[0_0_40px_rgba(59,130,246,0.1)]';
      case 'emerald':
        return 'bg-[#064e3b] border-[#047857] text-[#ecfdf5] shadow-[0_0_40px_rgba(16,185,129,0.2)]';
      case 'sand':
        return 'bg-[#f5eedc] border-[#e5d5b5] text-[#5c4d3c] shadow-[0_0_40px_rgba(217,119,6,0.1)]';
      default:
        return 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-900 dark:text-white';
    }
  };

  const getHighlightClasses = () => {
    switch (readingTheme) {
      case 'sepia': return 'text-amber-700 bg-amber-100/50';
      case 'islamic': return 'text-[#047857] bg-[#d1fae5]';
      case 'midnight': return 'text-gold-400 bg-slate-800';
      case 'emerald': return 'text-gold-400 bg-[#022c22]';
      case 'sand': return 'text-[#8b5a2b] bg-[#e8dcc4]';
      default: return 'text-islamic-600 dark:text-islamic-400 bg-islamic-50 dark:bg-islamic-900/30';
    }
  };

  const getHoverClasses = () => {
    switch (readingTheme) {
      case 'sepia': return 'hover:text-amber-700';
      case 'islamic': return 'hover:text-[#047857]';
      case 'midnight': return 'hover:text-gold-400';
      case 'emerald': return 'hover:text-gold-400';
      case 'sand': return 'hover:text-[#8b5a2b]';
      default: return 'hover:text-islamic-500';
    }
  };

  const getSymbolColor = () => {
    switch (readingTheme) {
      case 'sepia': return 'text-amber-600';
      case 'islamic': return 'text-[#059669]';
      case 'midnight': return 'text-gold-500';
      case 'emerald': return 'text-gold-500';
      case 'sand': return 'text-[#a67c52]';
      default: return 'text-islamic-500';
    }
  };

  if (selectedSurah) {
    return (
      <div className="max-w-4xl mx-auto pb-32 relative">
        {/* Header */}
        <div className="sticky top-16 z-30 bg-slate-50/90 dark:bg-slate-900/90 backdrop-blur-md py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between mb-8">
          <button 
            onClick={() => { setSelectedSurah(null); setIsPlaying(false); }}
            className="text-islamic-600 dark:text-islamic-400 hover:underline font-medium flex items-center gap-2"
          >
            <SkipBack size={16} className={language === 'ar' ? 'rotate-180' : ''} />
            {t('home')}
          </button>
          <div className="text-center">
            <h2 className="text-2xl font-bold font-arabic">{selectedSurah.name}</h2>
            <p className="text-sm text-slate-500">{selectedSurah.englishName} • {selectedSurah.numberOfAyahs} Ayahs</p>
          </div>
          <div className="flex gap-2 relative">
            <button 
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-full transition-colors ${showSettings ? 'bg-islamic-100 text-islamic-600 dark:bg-islamic-900/50 dark:text-islamic-400' : 'hover:bg-slate-200 dark:hover:bg-slate-800'}`}
            >
              <Settings size={20} />
            </button>

            {/* Settings Dropdown */}
            {showSettings && (
              <div className="absolute top-12 end-0 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 p-6 w-80 z-50">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-slate-900 dark:text-white">Reading Settings</h3>
                  <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-slate-600"><X size={18}/></button>
                </div>
                
                {/* Reciter */}
                <div className="mb-5">
                  <label className="block text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">Famous Reciter</label>
                  <select 
                    value={selectedReciter} 
                    onChange={(e) => setSelectedReciter(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-islamic-500"
                  >
                    {RECITERS.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                  </select>
                </div>

                {/* Font Size */}
                <div className="mb-5">
                  <label className="block text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">Font Size ({fontSize}px)</label>
                  <input 
                    type="range" min="24" max="64" 
                    value={fontSize} onChange={(e) => setFontSize(Number(e.target.value))}
                    className="w-full accent-islamic-500"
                  />
                </div>

                {/* Theme */}
                <div>
                  <label className="block text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">Reading Theme</label>
                  <div className="grid grid-cols-3 gap-2">
                    <button 
                      onClick={() => setReadingTheme('default')} 
                      className={`py-2 rounded-xl border font-medium text-sm transition-colors ${readingTheme === 'default' ? 'border-islamic-500 bg-islamic-50 text-islamic-700 dark:bg-islamic-900/30 dark:text-islamic-400' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}
                    >
                      Default
                    </button>
                    <button 
                      onClick={() => setReadingTheme('sepia')} 
                      className={`py-2 rounded-xl border font-medium text-sm transition-colors bg-[#f4ecd8] text-amber-900 ${readingTheme === 'sepia' ? 'border-amber-600 shadow-sm' : 'border-transparent opacity-80 hover:opacity-100'}`}
                    >
                      Sepia
                    </button>
                    <button 
                      onClick={() => setReadingTheme('islamic')} 
                      className={`py-2 rounded-xl border font-medium text-sm transition-colors bg-[#ecfdf5] text-[#064e3b] ${readingTheme === 'islamic' ? 'border-[#059669] shadow-sm' : 'border-transparent opacity-80 hover:opacity-100'}`}
                    >
                      Islamic
                    </button>
                    <button 
                      onClick={() => setReadingTheme('midnight')} 
                      className={`py-2 rounded-xl border font-medium text-sm transition-colors bg-[#0f172a] text-slate-300 ${readingTheme === 'midnight' ? 'border-blue-500 shadow-sm' : 'border-transparent opacity-80 hover:opacity-100'}`}
                    >
                      Midnight
                    </button>
                    <button 
                      onClick={() => setReadingTheme('emerald')} 
                      className={`py-2 rounded-xl border font-medium text-sm transition-colors bg-[#064e3b] text-emerald-100 ${readingTheme === 'emerald' ? 'border-emerald-400 shadow-sm' : 'border-transparent opacity-80 hover:opacity-100'}`}
                    >
                      Emerald
                    </button>
                    <button 
                      onClick={() => setReadingTheme('sand')} 
                      className={`py-2 rounded-xl border font-medium text-sm transition-colors bg-[#f5eedc] text-[#5c4d3c] ${readingTheme === 'sand' ? 'border-[#d4a373] shadow-sm' : 'border-transparent opacity-80 hover:opacity-100'}`}
                    >
                      Sand
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bismillah */}
        {selectedSurah.number !== 1 && selectedSurah.number !== 9 && (
          <div className="text-center mb-12">
            <p className={`font-arabic text-3xl ${
              readingTheme === 'sepia' ? 'text-[#4a3c24]' : 
              readingTheme === 'islamic' ? 'text-[#064e3b]' : 
              readingTheme === 'midnight' ? 'text-slate-300' :
              readingTheme === 'emerald' ? 'text-emerald-100' :
              readingTheme === 'sand' ? 'text-[#5c4d3c]' :
              'text-slate-800 dark:text-slate-200'
            }`}>
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </p>
          </div>
        )}

        {/* Ayahs - Displayed together */}
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-islamic-600"></div>
          </div>
        ) : (
          <div className={`rounded-3xl p-8 md:p-12 shadow-sm border transition-colors duration-300 ${getThemeClasses()}`}>
            {readingTheme === 'islamic' && (
              <>
                <div className="absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 border-islamic-500 rounded-tl-3xl opacity-50 m-4"></div>
                <div className="absolute top-0 right-0 w-16 h-16 border-t-4 border-r-4 border-islamic-500 rounded-tr-3xl opacity-50 m-4"></div>
                <div className="absolute bottom-0 left-0 w-16 h-16 border-b-4 border-l-4 border-islamic-500 rounded-bl-3xl opacity-50 m-4"></div>
                <div className="absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 border-islamic-500 rounded-br-3xl opacity-50 m-4"></div>
                <div className="absolute inset-0 opacity-5 pointer-events-none bg-[url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23059669\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]"></div>
              </>
            )}
            <p 
              className="font-arabic leading-[2.5] text-justify relative z-10" 
              style={{ fontSize: `${fontSize}px` }}
              dir="rtl"
            >
              {ayahs.map((ayah, index) => {
                let text = ayah.text;
                if (index === 0 && selectedSurah.number !== 1 && text.startsWith('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ ')) {
                  text = text.replace('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ ', '');
                }

                const isCurrent = index === currentAyahIndex;
                const isFav = favoriteVerses.some(v => v.id === `${selectedSurah.number}_${ayah.numberInSurah}`);

                return (
                  <span 
                    key={ayah.number}
                    onClick={() => handleVerseClick(index)}
                    className={`cursor-pointer transition-colors duration-300 relative group ${
                      isCurrent && isPlaying 
                        ? `${getHighlightClasses()} rounded-lg px-1`
                        : getHoverClasses()
                    }`}
                  >
                    {text}
                    <span className={`inline-flex items-center justify-center relative mx-2 select-none ${getSymbolColor()}`}>
                      <span className="text-[1.2em]">۝</span>
                      <span className="absolute text-[0.4em] font-sans font-bold">{ayah.numberInSurah}</span>
                    </span>
                    
                    {/* Favorite Button (Visible on hover or if active) */}
                    {(isCurrent || isFav) && (
                      <button 
                        onClick={(e) => handleFavoriteClick(e, ayah)}
                        className={`absolute -top-6 left-1/2 -translate-x-1/2 p-1 rounded-full bg-white dark:bg-slate-800 shadow-md border border-slate-200 dark:border-slate-700 z-10 ${isFav ? 'text-red-500' : 'text-slate-400 hover:text-red-500'}`}
                      >
                        <Heart size={14} fill={isFav ? "currentColor" : "none"} />
                      </button>
                    )}
                  </span>
                );
              })}
            </p>
          </div>
        )}

        {/* Surah Navigation */}
        {!loading && (
          <div className="flex justify-between items-center mt-12 pt-8 border-t border-slate-200 dark:border-slate-700">
            <button 
              onClick={() => navigateSurah(-1)} 
              disabled={selectedSurah.number === 1}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors disabled:opacity-50"
            >
              <ChevronLeft size={20} /> Previous Surah
            </button>
            <button 
              onClick={() => navigateSurah(1)} 
              disabled={selectedSurah.number === 114}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors disabled:opacity-50"
            >
              Next Surah <ChevronRight size={20} />
            </button>
          </div>
        )}

        {/* Floating Audio Player with Light Green Shadow */}
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-md glass rounded-full px-6 py-3 flex items-center justify-between shadow-[0_8px_30px_rgba(16,185,129,0.4)] border border-white/20 z-40">
          <button onClick={prevAyah} className="p-2 text-slate-700 dark:text-slate-200 hover:text-islamic-600">
            <SkipBack size={24} className={language === 'ar' ? 'rotate-180' : ''} />
          </button>
          <button 
            onClick={togglePlay} 
            className="w-14 h-14 flex items-center justify-center bg-islamic-600 text-white rounded-full shadow-lg hover:bg-islamic-700 transition-transform hover:scale-105"
          >
            {isPlaying ? <Pause size={28} /> : <Play size={28} className="ms-1" />}
          </button>
          <button onClick={nextAyah} className="p-2 text-slate-700 dark:text-slate-200 hover:text-islamic-600">
            <SkipForward size={24} className={language === 'ar' ? 'rotate-180' : ''} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <h1 className="text-3xl font-bold">{t('quran')}</h1>
        <div className="relative w-full md:w-72">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder={t('searchSurah')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full py-2 ps-10 pe-4 focus:outline-none focus:ring-2 focus:ring-islamic-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSurahs.map((surah) => (
          <button
            key={surah.number}
            onClick={() => loadSurah(surah)}
            className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700 hover:border-islamic-500 dark:hover:border-islamic-500 transition-all flex items-center justify-between group text-start"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-islamic-50 dark:bg-islamic-900/30 text-islamic-600 dark:text-islamic-400 flex items-center justify-center font-bold text-sm group-hover:bg-islamic-600 group-hover:text-white transition-colors">
                {surah.number}
              </div>
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white">{surah.englishName}</h3>
                <p className="text-xs text-slate-500">{surah.englishNameTranslation}</p>
              </div>
            </div>
            <div className="text-end">
              <h3 className="font-arabic text-xl font-bold text-islamic-700 dark:text-islamic-400">{surah.name}</h3>
              <p className="text-xs text-slate-500">{surah.numberOfAyahs} Ayahs</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default Quran;
