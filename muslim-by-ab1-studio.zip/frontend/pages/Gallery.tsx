import React, { useState, useRef, useEffect } from 'react';
import { ImagePlus, Share2, X, Trash2, Download } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface GalleryImage {
  id: string;
  url: string;
  date: string;
}

const Gallery: React.FC = () => {
  const { t } = useApp();
  const [images, setImages] = useState<GalleryImage[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const savedImages = localStorage.getItem('muslim_gallery');
    if (savedImages) {
      setImages(JSON.parse(savedImages));
    }
  }, []);

  const saveImages = (newImages: GalleryImage[]) => {
    setImages(newImages);
    localStorage.setItem('muslim_gallery', JSON.stringify(newImages));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newImages: GalleryImage[] = [];
    let processedCount = 0;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        newImages.push({
          id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
          url: reader.result as string,
          date: new Date().toLocaleDateString()
        });
        
        processedCount++;
        if (processedCount === files.length) {
          saveImages([...newImages, ...images]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this image?')) {
      saveImages(images.filter(img => img.id !== id));
    }
  };

  const handleShare = async (imageUrl: string) => {
    try {
      const res = await fetch(imageUrl);
      const blob = await res.blob();
      const file = new File([blob], 'islamic_share.jpg', { type: 'image/jpeg' });

      if (navigator.share) {
        await navigator.share({
          title: 'Shared from Muslim App',
          text: 'Check out this beautiful Islamic image!',
          files: [file]
        });
      } else {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'islamic_share.jpg';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        alert("Image downloaded. You can now share it manually.");
      }
    } catch (error) {
      console.error("Error sharing:", error);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">{t('gallery')}</h1>
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-2 bg-islamic-600 text-white px-6 py-3 rounded-full font-medium hover:bg-islamic-700 transition-colors shadow-sm"
        >
          <ImagePlus size={20} />
          Upload Photos
        </button>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleImageUpload} 
          accept="image/*" 
          multiple
          className="hidden" 
        />
      </div>

      {images.length === 0 ? (
        <div className="text-center py-20 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700">
          <ImagePlus size={64} className="mx-auto text-slate-300 dark:text-slate-600 mb-4" />
          <h3 className="text-xl font-bold text-slate-700 dark:text-slate-300 mb-2">Your Gallery is Empty</h3>
          <p className="text-slate-500 mb-6">Upload your favorite Islamic photos, quotes, or memories to share.</p>
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 bg-islamic-100 text-islamic-700 dark:bg-islamic-900/50 dark:text-islamic-300 px-6 py-3 rounded-full font-medium hover:bg-islamic-200 transition-colors"
          >
            <ImagePlus size={18} /> Browse Files
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {images.map((img) => (
            <div key={img.id} className="group relative rounded-3xl overflow-hidden bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 shadow-sm aspect-square">
              <img src={img.url} alt="Gallery item" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-4">
                <div className="flex justify-end">
                  <button 
                    onClick={() => handleDelete(img.id)}
                    className="p-2 bg-red-500/80 hover:bg-red-500 text-white rounded-full backdrop-blur-sm transition-colors"
                    title="Delete"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                
                <div className="flex justify-between items-end">
                  <span className="text-white/80 text-sm font-medium drop-shadow-md">{img.date}</span>
                  <button 
                    onClick={() => handleShare(img.url)}
                    className="flex items-center gap-2 bg-islamic-500 hover:bg-islamic-600 text-white px-4 py-2 rounded-full font-medium transition-colors backdrop-blur-sm"
                  >
                    <Share2 size={16} /> Share
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Gallery;
