import React, { useState, useEffect } from 'react';
import { MapPin, Compass, CheckCircle2, Circle, Sunrise, Edit2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PrayerTimes as PTType } from '../types';

const PrayerTimes: React.FC = () => {
  const { prayerTimes, location, nextPrayerName, countdown, updateLocation, t } = useApp();

  const [checklist, setChecklist] = useState<Record<string, boolean>>({});
  const [isEditingLoc, setIsEditingLoc] = useState(false);
  const [cityInput, setCityInput] = useState('');
  const [countryInput, setCountryInput] = useState('');
  const [isSavingLoc, setIsSavingLoc] = useState(false);

  useEffect(() => {
    const today = new Date().toDateString();
    const saved = localStorage.getItem(`muslim_checklist_${today}`);
    if (saved) {
      setChecklist(JSON.parse(saved));
    }
  }, []);

  const toggleCheck = (prayer: string) => {
    const today = new Date().toDateString();
    const newChecklist = { ...checklist, [prayer]: !checklist[prayer] };
    setChecklist(newChecklist);
    localStorage.setItem(`muslim_checklist_${today}`, JSON.stringify(newChecklist));
  };

  const handleEditLocationClick = () => {
    setCityInput(location.city);
    setCountryInput(location.country);
    setIsEditingLoc(true);
  };

  const handleSaveLocation = async () => {
    if (!cityInput.trim() || !countryInput.trim()) return;
    setIsSavingLoc(true);
    const success = await updateLocation(cityInput.trim(), countryInput.trim());
    setIsSavingLoc(false);
    if (success) {
      setIsEditingLoc(false);
    } else {
      alert("Could not find prayer times for this location. Please try again.");
    }
  };

  const prayers = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  const completedCount = prayers.filter(p => p !== 'Sunrise' && checklist[p]).length;
  const progress = (completedCount / 5) * 100;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header Card */}
      <div className="bg-gradient-to-r from-islamic-600 to-islamic-800 rounded-3xl p-8 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 end-0 opacity-10">
          <Compass size={200} className="-mt-10 -me-10" />
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="w-full md:w-auto">
            <h1 className="text-3xl font-bold mb-3">{t('prayerTimes')}</h1>
            
            {isEditingLoc ? (
              <div className="flex flex-col sm:flex-row gap-2 mt-2">
                <input 
                  type="text" 
                  value={cityInput} 
                  onChange={e => setCityInput(e.target.value)} 
                  placeholder="City (e.g. London)" 
                  className="bg-white/10 border border-white/20 text-white placeholder:text-white/50 px-3 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-white/50 text-sm w-full sm:w-auto"
                />
                <input 
                  type="text" 
                  value={countryInput} 
                  onChange={e => setCountryInput(e.target.value)} 
                  placeholder="Country (e.g. UK)" 
                  className="bg-white/10 border border-white/20 text-white placeholder:text-white/50 px-3 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-white/50 text-sm w-full sm:w-auto"
                />
                <div className="flex gap-2 mt-2 sm:mt-0">
                  <button 
                    onClick={handleSaveLocation} 
                    disabled={isSavingLoc}
                    className="bg-white text-islamic-700 px-4 py-2 rounded-lg text-sm font-bold hover:bg-islamic-50 transition-colors disabled:opacity-50"
                  >
                    {isSavingLoc ? '...' : 'Save'}
                  </button>
                  <button 
                    onClick={() => setIsEditingLoc(false)} 
                    className="bg-black/20 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-black/30 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <button 
                onClick={handleEditLocationClick}
                className="flex items-center gap-2 text-islamic-100 hover:text-white transition-colors group bg-white/10 px-3 py-1.5 rounded-lg backdrop-blur-sm border border-white/10"
                title="Change Location"
              >
                <MapPin size={18} /> 
                <span className="font-medium">{location.city}, {location.country}</span>
                <Edit2 size={14} className="opacity-50 group-hover:opacity-100 ms-1" />
              </button>
            )}
          </div>
          
          <div className="bg-white/20 backdrop-blur-md rounded-2xl p-6 text-center min-w-[200px] w-full md:w-auto">
            <p className="text-sm text-islamic-100 mb-1">{t('nextPrayer')}</p>
            <h2 className="text-3xl font-bold mb-2">{t(nextPrayerName)}</h2>
            <p className="text-xl font-mono">{countdown}</p>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-700">
        <div className="flex justify-between items-end mb-2">
          <h3 className="font-semibold text-slate-700 dark:text-slate-200">{t('dailyHabits')}</h3>
          <span className="text-sm font-bold text-islamic-600 dark:text-islamic-400">{completedCount}/5 {t('completed')}</span>
        </div>
        <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-3 overflow-hidden">
          <div 
            className="bg-islamic-500 h-3 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      {/* Prayer List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {prayerTimes ? prayers.map((prayer) => {
          const time = prayerTimes[prayer as keyof PTType];
          const isSunrise = prayer === 'Sunrise';
          const isChecked = checklist[prayer] || false;

          return (
            <div 
              key={prayer}
              className={`flex items-center justify-between p-6 rounded-2xl border transition-all
                ${isSunrise ? 'bg-amber-50 dark:bg-amber-900/10 border-amber-100 dark:border-amber-900/30' : 
                  isChecked ? 'bg-islamic-50 dark:bg-islamic-900/20 border-islamic-200 dark:border-islamic-800' : 
                  'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 hover:border-islamic-300'}`}
            >
              <div className="flex items-center gap-4">
                {!isSunrise && (
                  <button 
                    onClick={() => toggleCheck(prayer)}
                    className={`transition-colors ${isChecked ? 'text-islamic-500' : 'text-slate-300 hover:text-islamic-400'}`}
                  >
                    {isChecked ? <CheckCircle2 size={28} /> : <Circle size={28} />}
                  </button>
                )}
                {isSunrise && <Sunrise size={28} className="text-amber-500" />}
                
                <div>
                  <h3 className={`text-xl font-bold ${isSunrise ? 'text-amber-700 dark:text-amber-500' : 'text-slate-800 dark:text-white'}`}>
                    {t(prayer)}
                  </h3>
                </div>
              </div>
              
              <div className="text-2xl font-mono font-light text-slate-600 dark:text-slate-300">
                {time}
              </div>
            </div>
          );
        }) : (
          // Loading skeletons
          [...Array(6)].map((_, i) => (
            <div key={i} className="h-24 bg-slate-200 dark:bg-slate-800 rounded-2xl animate-pulse"></div>
          ))
        )}
      </div>
    </div>
  );
};

export default PrayerTimes;
