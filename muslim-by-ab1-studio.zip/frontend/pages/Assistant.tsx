import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User as UserIcon, Loader2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ChatMessage } from '../types';
import { GoogleGenAI } from '@google/genai';

const Assistant: React.FC = () => {
  const { language, t } = useApp();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'model',
      text: language === 'ar' 
        ? 'السلام عليكم! أنا مساعدك الإسلامي الذكي. كيف يمكنني مساعدتك اليوم في أمور دينك؟' 
        : 'As-salamu alaykum! I am your Islamic AI assistant. How can I help you today with your faith?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      // Initialize Gemini API
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || 'dummy', vertexai: true });
      
      // Format history for Gemini
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: 'You are a knowledgeable, respectful, and helpful Islamic AI assistant. Answer questions related to Islam, Quran, Hadith, and Islamic history accurately and concisely. Always maintain a polite and respectful tone. If you do not know something, admit it. Do not give fatwas (legal rulings), but rather quote Quran and authentic Hadith.',
        }
      });

      // Send history and new message
      // Note: In a real app, we'd pass history to chat creation, but for simplicity we just send the new message
      // if the API supports history in create, we'd use it. Here we just send the message.
      const response = await chat.sendMessage({ message: userMsg.text });

      const modelMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: response.text || 'Sorry, I could not process that request.',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, modelMsg]);
    } catch (error) {
      console.error("AI Error:", error);
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: 'Sorry, I encountered an error connecting to the AI service. Please try again later.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-12rem)] flex flex-col">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-full bg-islamic-100 dark:bg-islamic-900/30 text-islamic-600 dark:text-islamic-400 flex items-center justify-center">
          <Bot size={24} />
        </div>
        <div>
          <h1 className="text-2xl font-bold">{t('assistant')}</h1>
          <p className="text-sm text-slate-500">Powered by Gemini AI</p>
        </div>
      </div>

      <div className="flex-1 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 overflow-hidden flex flex-col shadow-sm">
        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                msg.role === 'user' 
                  ? 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300' 
                  : 'bg-islamic-100 dark:bg-islamic-900/30 text-islamic-600 dark:text-islamic-400'
              }`}>
                {msg.role === 'user' ? <UserIcon size={20} /> : <Bot size={20} />}
              </div>
              <div className={`max-w-[80%] rounded-2xl p-4 ${
                msg.role === 'user' 
                  ? 'bg-islamic-600 text-white rounded-tr-none' 
                  : 'bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700 rounded-tl-none'
              }`}>
                <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                <span className={`text-xs mt-2 block ${msg.role === 'user' ? 'text-islamic-200' : 'text-slate-400'}`}>
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-islamic-100 dark:bg-islamic-900/30 text-islamic-600 dark:text-islamic-400 flex items-center justify-center shrink-0">
                <Bot size={20} />
              </div>
              <div className="bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700 rounded-2xl rounded-tl-none p-4 flex items-center gap-2">
                <Loader2 size={20} className="animate-spin text-islamic-500" />
                <span className="text-slate-500 text-sm">Thinking...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-700">
          <div className="relative flex items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask anything about Islam..."
              className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full py-3 ps-6 pe-14 focus:outline-none focus:ring-2 focus:ring-islamic-500 shadow-sm"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="absolute end-2 w-10 h-10 rounded-full bg-islamic-600 text-white flex items-center justify-center hover:bg-islamic-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={18} className="ms-1" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Assistant;
