import React, { useState } from 'react';
import { Settings, LogOut, ChevronRight, Bell, Shield, CircleHelp, Moon, Globe, Edit2, Camera, Check, X, BookOpen, Heart, Mail, Volume2, Mic2, Play } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS, FOUNDER_EMAIL, ADHANS, RECITERS } from '../constants';

const Profile: React.FC = () => {
  const { 
    language, setLanguage, theme, setTheme, user, login, logout, updateProfile, 
    lastRead, favoriteVerses, t,
    selectedAdhan, setSelectedAdhan, selectedReciter, setSelectedReciter,
    notificationsEnabled, requestNotificationPermission, setActiveAdhan
  } = useApp();

  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState('');
  const [editPhoto, setEditPhoto] = useState('');
  
  // Modals
  const [activeModal, setActiveModal] = useState<'privacy' | 'help' | 'contact' | 'adhan' | 'reciter' | 'notifications' | null>(null);

  if (!user) {
    return (
      <div className="max-w-md mx-auto mt-20 text-center space-y-6">
        <div className="w-24 h-24 bg-islamic-100 dark:bg-islamic-900/30 rounded-full flex items-center justify-center mx-auto text-islamic-600">
          <Shield size={40} />
        </div>
        <h2 className="text-2xl font-bold">Sign in to your account</h2>
        <p className="text-slate-500">Save your progress, bookmarks, and streaks across all your devices.</p>
        <button 
          onClick={login}
          className="w-full bg-islamic-600 hover:bg-islamic-700 text-white font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
          </svg>
          Continue with Google
        </button>
      </div>
    );
  }

  const isFounder = user.email === FOUNDER_EMAIL;

  const handleEditClick = () => {
    setEditName(user.displayName);
    setEditPhoto(user.photoURL);
    setIsEditingProfile(true);
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = () => {
    if (editName.trim()) {
      updateProfile(editName.trim(), editPhoto);
    }
    setIsEditingProfile(false);
  };

  const playAdhanPreview = (url: string) => {
    const audio = new Audio(url);
    audio.play().catch(e => console.error("Audio preview failed", e));
  };

  const playReciterPreview = async (reciterId: string) => {
    try {
      // Fetch Surah Al-Fatihah, Ayah 1 for the selected reciter
      const res = await fetch(`https://api.alquran.cloud/v1/ayah/1/${reciterId}`);
      const data = await res.json();
      if (data.data && data.data.audio) {
        const audio = new Audio(data.data.audio);
        audio.play().catch(e => console.error("Reciter preview failed", e));
      }
    } catch (err) {
      console.error("Failed to fetch reciter preview", err);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 relative">
      {/* Profile Header */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 border border-slate-100 dark:border-slate-700 flex flex-col md:flex-row items-center gap-6 text-center md:text-start relative overflow-hidden">
        {isFounder && (
          <div className="absolute top-0 end-0 bg-gold-400 text-amber-950 text-xs font-bold px-4 py-1 rounded-bl-xl flex items-center gap-1 z-10">
            👑 AB1 Studio Founder
          </div>
        )}
        
        <div className="relative group">
          <img 
            src={isEditingProfile ? editPhoto : user.photoURL} 
            alt={user.displayName} 
            className={`w-24 h-24 rounded-full object-cover border-4 ${isFounder ? 'border-gold-400' : 'border-islamic-500'}`} 
          />
          {isEditingProfile && (
            <label className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full cursor-pointer transition-opacity">
              <Camera className="text-white" size={24} />
              <input type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
            </label>
          )}
        </div>

        <div className="flex-1 w-full">
          {isEditingProfile ? (
            <div className="space-y-3">
              <input 
                type="text" 
                value={editName} 
                onChange={e => setEditName(e.target.value)} 
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-islamic-500 font-bold text-xl text-center md:text-start"
                placeholder="Your Name"
              />
              <div className="flex justify-center md:justify-start gap-2">
                <button onClick={handleSaveProfile} className="bg-islamic-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-islamic-700 transition-colors flex items-center gap-1">
                  <Check size={16}/> Save
                </button>
                <button onClick={() => setIsEditingProfile(false)} className="bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-lg text-sm font-bold hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors flex items-center gap-1">
                  <X size={16}/> Cancel
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-center md:justify-start gap-3">
                <h1 className="text-2xl font-bold flex items-center gap-2">
                  {user.displayName}
                  {isFounder && <span className="text-gold-500" title="Founder">👑</span>}
                </h1>
                <button onClick={handleEditClick} className="text-slate-400 hover:text-islamic-600 transition-colors p-1">
                  <Edit2 size={16} />
                </button>
              </div>
              <p className="text-slate-500 mb-2">{user.email}</p>
              <p className="text-sm text-islamic-600 dark:text-islamic-400 font-medium">Member since {new Date(user.memberSince).getFullYear()}</p>
            </>
          )}
        </div>
      </div>

      {/* Quran Journey Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Last Read */}
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700 flex items-center gap-4 hover:border-islamic-500 transition-colors cursor-pointer">
          <div className="w-12 h-12 rounded-full bg-islamic-50 dark:bg-islamic-900/30 text-islamic-600 dark:text-islamic-400 flex items-center justify-center">
            <BookOpen size={24} />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 dark:text-white">{t('continueReading')}</h3>
            {lastRead ? (
              <p className="text-sm text-slate-500">{lastRead.surahName} • {t('ayah')} {lastRead.ayahNumber}</p>
            ) : (
              <p className="text-sm text-slate-500">{t('noLastRead')}</p>
            )}
          </div>
        </div>

        {/* Favorites */}
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700 flex items-center gap-4 hover:border-red-500 transition-colors cursor-pointer">
          <div className="w-12 h-12 rounded-full bg-red-50 dark:bg-red-900/30 text-red-500 flex items-center justify-center">
            <Heart size={24} />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 dark:text-white">{t('favoriteVerses')}</h3>
            <p className="text-sm text-slate-500">{favoriteVerses.length} {t('savedAyahs')}</p>
          </div>
        </div>
      </div>

      {/* Settings List */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
          <h3 className="font-bold text-slate-500 uppercase tracking-wider text-xs">{t('settings')}</h3>
        </div>
        
        <div className="divide-y divide-slate-100 dark:divide-slate-700">
          <button 
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300"><Moon size={20} /></div>
              <span className="font-medium">Dark Mode</span>
            </div>
            <div className={`w-12 h-6 rounded-full transition-colors relative ${theme === 'dark' ? 'bg-islamic-500' : 'bg-slate-300 dark:bg-slate-600'}`}>
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${theme === 'dark' ? 'start-7' : 'start-1'}`}></div>
            </div>
          </button>

          <button 
            onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300"><Globe size={20} /></div>
              <span className="font-medium">Language</span>
            </div>
            <span className="text-slate-500 font-medium">{language === 'en' ? 'English' : 'العربية'}</span>
          </button>

          <button 
            onClick={() => setActiveModal('adhan')}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300"><Volume2 size={20} /></div>
              <span className="font-medium">Adhan Sound</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-medium text-sm">{ADHANS.find(a => a.id === selectedAdhan)?.name}</span>
              <ChevronRight size={20} className="text-slate-400" />
            </div>
          </button>

          <button 
            onClick={() => setActiveModal('reciter')}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300"><Mic2 size={20} /></div>
              <span className="font-medium">Quran Reciter</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-medium text-sm">{RECITERS.find(r => r.id === selectedReciter)?.name}</span>
              <ChevronRight size={20} className="text-slate-400" />
            </div>
          </button>

          <button 
            onClick={() => setActiveModal('notifications')}
            className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300"><Bell size={20} /></div>
              <span className="font-medium">Notifications</span>
            </div>
            <div className={`w-12 h-6 rounded-full transition-colors relative ${notificationsEnabled ? 'bg-islamic-500' : 'bg-slate-300 dark:bg-slate-600'}`}>
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${notificationsEnabled ? 'start-7' : 'start-1'}`}></div>
            </div>
          </button>

          <button onClick={() => setActiveModal('privacy')} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300"><Shield size={20} /></div>
              <span className="font-medium">Privacy & Security</span>
            </div>
            <ChevronRight size={20} className="text-slate-400" />
          </button>

          <button onClick={() => setActiveModal('help')} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300"><CircleHelp size={20} /></div>
              <span className="font-medium">Help & Support</span>
            </div>
            <ChevronRight size={20} className="text-slate-400" />
          </button>

          <button onClick={() => setActiveModal('contact')} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300"><Mail size={20} /></div>
              <span className="font-medium">Contact Us</span>
            </div>
            <ChevronRight size={20} className="text-slate-400" />
          </button>
        </div>
      </div>

      <button 
        onClick={logout}
        className="w-full bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 font-bold py-4 rounded-2xl transition-colors flex items-center justify-center gap-2 hover:bg-red-100 dark:hover:bg-red-900/40"
      >
        <LogOut size={20} />
        {t('logout')}
      </button>

      {/* Modals */}
      {activeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-xl max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold capitalize">{activeModal.replace('-', ' ')}</h3>
              <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-slate-600"><X size={20}/></button>
            </div>

            {activeModal === 'notifications' && (
              <div className="space-y-4 text-slate-600 dark:text-slate-300">
                <p>Enable notifications to receive alerts for prayer times and daily reminders.</p>
                <button 
                  onClick={requestNotificationPermission}
                  className="w-full bg-islamic-600 text-white py-3 rounded-xl font-bold hover:bg-islamic-700 transition-colors"
                >
                  {notificationsEnabled ? 'Permissions Granted' : 'Enable Permissions'}
                </button>
                
                <button 
                  onClick={() => {
                    if (Notification.permission === 'granted') {
                      new Notification('Test Notification', { body: 'Notifications are working perfectly!' });
                    }
                    const adhanObj = ADHANS.find(a => a.id === selectedAdhan) || ADHANS[0];
                    setActiveAdhan({ prayer: 'Test Adhan', url: adhanObj.url });
                    setActiveModal(null);
                  }}
                  className="w-full mt-4 bg-islamic-100 text-islamic-700 py-3 rounded-xl font-bold hover:bg-islamic-200 transition-colors"
                >
                  Test Notification & Adhan
                </button>
              </div>
            )}

            {activeModal === 'privacy' && (
              <div className="space-y-4 text-slate-600 dark:text-slate-300">
                <p><strong>Privacy Policy</strong></p>
                <p>Your privacy is important to us. We only store your preferences and progress locally on your device or securely in your account if you sign in.</p>
                <p>We do not share your location data. It is only used to calculate accurate prayer times.</p>
                <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-xl mt-4">
                  <h4 className="font-bold text-slate-900 dark:text-white mb-2">Email Permissions</h4>
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 text-islamic-600 rounded focus:ring-islamic-500" defaultChecked />
                    <span className="text-sm">Receive weekly Islamic reminders</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer mt-2">
                    <input type="checkbox" className="w-4 h-4 text-islamic-600 rounded focus:ring-islamic-500" defaultChecked />
                    <span className="text-sm">Receive product updates from AB1 Studio</span>
                  </label>
                </div>
              </div>
            )}

            {activeModal === 'help' && (
              <div className="space-y-4 text-slate-600 dark:text-slate-300">
                <p><strong>Help & Support</strong></p>
                <p>If you are experiencing issues with prayer times, please ensure your location permissions are enabled.</p>
                <p>For audio playback issues, check your device's volume and ensure you are not on silent mode.</p>
                <p>You can also use our AI Assistant for any Islamic questions.</p>
              </div>
            )}

            {activeModal === 'contact' && (
              <div className="space-y-4 text-slate-600 dark:text-slate-300 text-center py-4">
                <Mail size={48} className="mx-auto text-islamic-500 mb-4" />
                <p>Have questions or feedback? Reach out to us at:</p>
                <a href="mailto:abayobihqt@gmail.com" className="text-lg font-bold text-islamic-600 hover:underline">abayobihqt@gmail.com</a>
              </div>
            )}

            {activeModal === 'adhan' && (
              <div className="space-y-2">
                {ADHANS.map(adhan => (
                  <div key={adhan.id} className={`flex items-center justify-between p-4 rounded-xl border transition-colors ${selectedAdhan === adhan.id ? 'border-islamic-500 bg-islamic-50 dark:bg-islamic-900/30 text-islamic-700 dark:text-islamic-400 font-bold' : 'border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}>
                    <button 
                      onClick={() => { setSelectedAdhan(adhan.id); setActiveModal(null); }}
                      className="flex-1 text-start"
                    >
                      {adhan.name}
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        playAdhanPreview(adhan.url);
                      }}
                      className="p-2 text-islamic-600 hover:bg-islamic-100 dark:hover:bg-islamic-900/50 rounded-full transition-colors"
                      title="Preview Adhan"
                    >
                      <Play size={18} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {activeModal === 'reciter' && (
              <div className="space-y-2">
                {RECITERS.map(reciter => (
                  <div key={reciter.id} className={`flex items-center justify-between p-4 rounded-xl border transition-colors ${selectedReciter === reciter.id ? 'border-islamic-500 bg-islamic-50 dark:bg-islamic-900/30 text-islamic-700 dark:text-islamic-400 font-bold' : 'border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50'}`}>
                    <button 
                      onClick={() => { setSelectedReciter(reciter.id); setActiveModal(null); }}
                      className="flex-1 text-start"
                    >
                      {reciter.name}
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        playReciterPreview(reciter.id);
                      }}
                      className="p-2 text-islamic-600 hover:bg-islamic-100 dark:hover:bg-islamic-900/50 rounded-full transition-colors"
                      title="Preview Reciter"
                    >
                      <Play size={18} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;
