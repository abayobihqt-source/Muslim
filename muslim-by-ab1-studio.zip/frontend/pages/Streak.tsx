import React from 'react';
import { Flame, Trophy, Calendar as CalendarIcon, Star, Activity, Shield, RotateCcw } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS, DEFAULT_ADHKAR } from '../constants';
import { AdhkarItem } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const Streak: React.FC = () => {
  const { language, user, login, quranAyahsReadToday, streakData, resetStreak } = useApp();
  const t = (key: string) => TRANSLATIONS[key]?.[language] || key;

  if (!user) {
    // Reset data to 0 for new users
    const emptyData = [
      { name: 'Mon', score: 0 },
      { name: 'Tue', score: 0 },
      { name: 'Wed', score: 0 },
      { name: 'Thu', score: 0 },
      { name: 'Fri', score: 0 },
      { name: 'Sat', score: 0 },
      { name: 'Sun', score: 0 },
    ];

    return (
      <div className="max-w-4xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold">{t('streak')}</h1>

        {/* Main Stats - Empty State */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-orange-400 to-red-500 rounded-3xl p-6 text-white shadow-lg flex flex-col items-center justify-center text-center relative overflow-hidden opacity-50">
            <Flame size={100} className="absolute -end-4 -bottom-4 opacity-20" />
            <Flame size={40} className="mb-2" />
            <h3 className="text-5xl font-bold mb-1">0</h3>
            <p className="font-medium opacity-90">{t('dayStreak')}</p>
          </div>
          
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center text-center opacity-50">
            <Trophy size={40} className="text-gold-500 mb-2" />
            <h3 className="text-4xl font-bold text-slate-800 dark:text-white mb-1">0</h3>
            <p className="text-slate-500 font-medium">{t('longestStreak')}</p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center text-center opacity-50">
            <Star size={40} className="text-islamic-500 mb-2" />
            <h3 className="text-4xl font-bold text-slate-800 dark:text-white mb-1">0</h3>
            <p className="text-slate-500 font-medium">{t('totalPoints')}</p>
          </div>
        </div>

        {/* Sign In Prompt */}
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-8 border border-slate-100 dark:border-slate-700 text-center space-y-6">
          <div className="w-20 h-20 bg-islamic-100 dark:bg-islamic-900/30 rounded-full flex items-center justify-center mx-auto text-islamic-600">
            <Shield size={32} />
          </div>
          <div>
            <h2 className="text-2xl font-bold mb-2">Sign in to track your streak</h2>
            <p className="text-slate-500 max-w-md mx-auto">Start building your daily Islamic habits and track your progress by signing in.</p>
          </div>
          <button 
            onClick={login}
            className="bg-islamic-600 hover:bg-islamic-700 text-white font-bold py-3 px-8 rounded-xl transition-colors inline-flex items-center justify-center gap-2"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Continue with Google
          </button>
        </div>

        {/* Chart - Empty State */}
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700 opacity-50">
          <h3 className="font-bold text-lg mb-6 flex items-center gap-2">
            <Activity size={20} className="text-islamic-500" /> {t('weeklyActivity')}
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={emptyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" axisLine={false} tickLine={false} />
                <YAxis hide domain={[0, 100]} />
                <Line 
                  type="monotone" 
                  dataKey="score" 
                  stroke="#94a3b8" 
                  strokeWidth={4}
                  dot={{ r: 6, fill: '#94a3b8', strokeWidth: 2, stroke: '#fff' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    );
  }

  // Calculate Progress
  const today = new Date().toDateString();
  
  // Prayers
  const savedChecklist = localStorage.getItem(`muslim_checklist_${today}`);
  const checklist = savedChecklist ? JSON.parse(savedChecklist) : {};
  const prayers = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  const completedPrayers = prayers.filter(p => checklist[p]).length;
  const prayerProgress = Math.round((completedPrayers / 5) * 100);

  // Adhkar
  const savedAdhkar = localStorage.getItem('muslim_adhkar_list');
  const adhkarList: AdhkarItem[] = savedAdhkar ? JSON.parse(savedAdhkar) : DEFAULT_ADHKAR;
  
  const calcProgress = (list: AdhkarItem[]) => {
    if (list.length === 0) return 0;
    const total = list.reduce((acc, item) => acc + item.count, 0);
    const current = list.reduce((acc, item) => acc + item.currentCount, 0);
    return Math.min(100, Math.round((current / total) * 100));
  };

  const morningProgress = calcProgress(adhkarList.filter(a => a.category === 'morning'));
  const eveningProgress = calcProgress(adhkarList.filter(a => a.category === 'evening'));

  // Quran
  const quranProgress = Math.min(100, Math.round((quranAyahsReadToday / 10) * 100));

  // Mock Chart Data
  const data = [
    { name: 'Mon', score: 80 },
    { name: 'Tue', score: 100 },
    { name: 'Wed', score: 60 },
    { name: 'Thu', score: 100 },
    { name: 'Fri', score: 100 },
    { name: 'Sat', score: 40 },
    { name: 'Sun', score: Math.round((prayerProgress + morningProgress + eveningProgress + quranProgress) / 4) },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">{t('streak')}</h1>
        <button 
          onClick={() => {
            if (window.confirm('Are you sure you want to reset your streak data?')) {
              resetStreak();
            }
          }}
          className="flex items-center gap-2 text-sm text-slate-500 hover:text-red-500 transition-colors px-3 py-1.5 rounded-full hover:bg-red-50 dark:hover:bg-red-900/20"
        >
          <RotateCcw size={16} /> Reset
        </button>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-orange-400 to-red-500 rounded-3xl p-6 text-white shadow-lg flex flex-col items-center justify-center text-center relative overflow-hidden">
          <Flame size={100} className="absolute -end-4 -bottom-4 opacity-20" />
          <Flame size={40} className="mb-2" />
          <h3 className="text-5xl font-bold mb-1">{streakData.current}</h3>
          <p className="font-medium opacity-90">{t('dayStreak')}</p>
        </div>
        
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center text-center">
          <Trophy size={40} className="text-gold-500 mb-2" />
          <h3 className="text-4xl font-bold text-slate-800 dark:text-white mb-1">{streakData.longest}</h3>
          <p className="text-slate-500 font-medium">{t('longestStreak')}</p>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700 flex flex-col items-center justify-center text-center">
          <Star size={40} className="text-islamic-500 mb-2" />
          <h3 className="text-4xl font-bold text-slate-800 dark:text-white mb-1">{streakData.points}</h3>
          <p className="text-slate-500 font-medium">{t('totalPoints')}</p>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700">
        <h3 className="font-bold text-lg mb-6 flex items-center gap-2">
          <Activity size={20} className="text-islamic-500" /> {t('weeklyActivity')}
        </h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="name" stroke="#94a3b8" axisLine={false} tickLine={false} />
              <YAxis hide domain={[0, 100]} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                cursor={{ stroke: '#10b981', strokeWidth: 1, strokeDasharray: '5 5' }}
              />
              <Line 
                type="monotone" 
                dataKey="score" 
                stroke="#10b981" 
                strokeWidth={4}
                dot={{ r: 6, fill: '#10b981', strokeWidth: 2, stroke: '#fff' }}
                activeDot={{ r: 8 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Habits */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-100 dark:border-slate-700">
        <h3 className="font-bold text-lg mb-4">{t('dailyHabits')}</h3>
        <div className="space-y-4">
          {[
            { name: t('readQuran'), progress: quranProgress, color: 'bg-islamic-500' },
            { name: t('pray5Times'), progress: prayerProgress, color: 'bg-blue-500' },
            { name: t('morningAdhkar'), progress: morningProgress, color: 'bg-amber-500' },
            { name: t('eveningAdhkar'), progress: eveningProgress, color: 'bg-indigo-500' },
          ].map((habit, idx) => (
            <div key={idx}>
              <div className="flex justify-between text-sm font-medium mb-1">
                <span>{habit.name}</span>
                <span>{habit.progress}%</span>
              </div>
              <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-2.5">
                <div className={`${habit.color} h-2.5 rounded-full transition-all duration-500`} style={{ width: `${habit.progress}%` }}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Streak;
