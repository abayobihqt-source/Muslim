import React, { useState, useEffect } from 'react';
import { Sunrise, Sunset, Moon, Shield, Heart, Plus, CheckCircle2, BookOpen, ListPlus, X, Trash2, Bell, BellOff } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DEFAULT_ADHKAR } from '../constants';
import { AdhkarItem, AdhkarCategory } from '../types';

const ICON_MAP: Record<string, React.ElementType> = {
  Sunrise, Sunset, Moon, Shield, Heart, BookOpen, ListPlus
};

const DEFAULT_CATEGORIES: AdhkarCategory[] = [
  { id: 'morning', iconName: 'Sunrise', label: 'morningAdhkar', color: 'text-amber-500', bg: 'bg-amber-100 dark:bg-amber-900/30' },
  { id: 'evening', iconName: 'Sunset', label: 'eveningAdhkar', color: 'text-indigo-500', bg: 'bg-indigo-100 dark:bg-indigo-900/30' },
  { id: 'sleep', iconName: 'Moon', label: 'beforeSleep', color: 'text-blue-500', bg: 'bg-blue-100 dark:bg-blue-900/30' },
  { id: 'protection', iconName: 'Shield', label: 'protection', color: 'text-emerald-500', bg: 'bg-emerald-100 dark:bg-emerald-900/30' },
];

const Adhkar: React.FC = () => {
  const { t, adhkarNotifications, toggleAdhkarNotification, notificationsEnabled } = useApp();

  // State for Categories and Adhkar
  const [categories, setCategories] = useState<AdhkarCategory[]>(() => {
    const saved = localStorage.getItem('muslim_adhkar_categories');
    return saved ? JSON.parse(saved) : DEFAULT_CATEGORIES;
  });

  const [adhkarList, setAdhkarList] = useState<AdhkarItem[]>(() => {
    const saved = localStorage.getItem('muslim_adhkar_list');
    return saved ? JSON.parse(saved) : DEFAULT_ADHKAR;
  });

  const [activeCategory, setActiveCategory] = useState('morning');

  // Modals State
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');

  const [isAdhkarModalOpen, setIsAdhkarModalOpen] = useState(false);
  const [newAdhkarArabic, setNewAdhkarArabic] = useState('');
  const [newAdhkarTranslation, setNewAdhkarTranslation] = useState('');
  const [newAdhkarCount, setNewAdhkarCount] = useState(1);

  // Save to Local Storage
  useEffect(() => {
    localStorage.setItem('muslim_adhkar_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('muslim_adhkar_list', JSON.stringify(adhkarList));
  }, [adhkarList]);

  // Handlers
  const handleCount = (id: string) => {
    setAdhkarList(prev => prev.map(item => {
      if (item.id === id && item.currentCount < item.count) {
        return { ...item, currentCount: item.currentCount + 1 };
      }
      return item;
    }));
  };

  const resetCount = (id: string) => {
    setAdhkarList(prev => prev.map(item => item.id === id ? { ...item, currentCount: 0 } : item));
  };

  const handleDeleteAdhkar = (id: string) => {
    if (window.confirm('Are you sure you want to delete this Adhkar?')) {
      setAdhkarList(prev => prev.filter(item => item.id !== id));
    }
  };

  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return;
    const newCat: AdhkarCategory = {
      id: 'cat_' + Date.now(),
      iconName: 'Heart', // Default icon for custom categories
      label: newCategoryName.trim(),
      color: 'text-islamic-500',
      bg: 'bg-islamic-100 dark:bg-islamic-900/30'
    };
    setCategories([...categories, newCat]);
    setNewCategoryName('');
    setIsCategoryModalOpen(false);
    setActiveCategory(newCat.id);
  };

  const handleAddAdhkar = () => {
    if (!newAdhkarArabic.trim()) return;
    const newAdhkar: AdhkarItem = {
      id: 'adhkar_' + Date.now(),
      category: activeCategory,
      arabic: newAdhkarArabic.trim(),
      translation: newAdhkarTranslation.trim(),
      count: newAdhkarCount,
      currentCount: 0
    };
    setAdhkarList([...adhkarList, newAdhkar]);
    setNewAdhkarArabic('');
    setNewAdhkarTranslation('');
    setNewAdhkarCount(1);
    setIsAdhkarModalOpen(false);
  };

  const getCategoryLabel = (label: string) => {
    // If it's a default category, translate it. Otherwise, use the custom name.
    const translated = t(label);
    return translated !== label ? translated : label;
  };

  const activeAdhkar = adhkarList.filter(a => a.category === activeCategory);

  return (
    <div className="max-w-4xl mx-auto relative">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{t('adhkar')}</h1>
        <button 
          onClick={() => setIsAdhkarModalOpen(true)}
          className="flex items-center gap-2 bg-islamic-600 text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-islamic-700 transition-colors shadow-sm"
        >
          <Plus size={16} /> Add Adhkar
        </button>
      </div>

      {/* Categories */}
      <div className="flex overflow-x-auto pb-4 gap-4 hide-scrollbar mb-6">
        {categories.map(cat => {
          const IconComponent = ICON_MAP[cat.iconName] || Heart;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-3 px-6 py-4 rounded-2xl whitespace-nowrap transition-all border
                ${activeCategory === cat.id 
                  ? 'bg-white dark:bg-slate-800 border-islamic-500 shadow-md' 
                  : 'bg-transparent border-slate-200 dark:border-slate-700 hover:bg-white/50 dark:hover:bg-slate-800/50'}`}
            >
              <div className={`p-2 rounded-full ${cat.bg} ${cat.color}`}>
                <IconComponent size={20} />
              </div>
              <span className="font-semibold">{getCategoryLabel(cat.label)}</span>
            </button>
          );
        })}
        
        {/* Add Category Button */}
        <button
          onClick={() => setIsCategoryModalOpen(true)}
          className="flex items-center gap-3 px-6 py-4 rounded-2xl whitespace-nowrap transition-all border border-dashed border-slate-300 dark:border-slate-600 text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/50"
        >
          <div className="p-2 rounded-full bg-slate-100 dark:bg-slate-800">
            <Plus size={20} />
          </div>
          <span className="font-semibold">New Category</span>
        </button>
      </div>

      {/* Adhkar List */}
      <div className="space-y-6">
        {activeAdhkar.length === 0 ? (
          <div className="text-center py-12 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700">
            <Heart size={48} className="mx-auto text-slate-300 dark:text-slate-600 mb-4" />
            <h3 className="text-xl font-bold text-slate-700 dark:text-slate-300 mb-2">No Adhkar Found</h3>
            <p className="text-slate-500 mb-6">You haven't added any Adhkar to this category yet.</p>
            <button 
              onClick={() => setIsAdhkarModalOpen(true)}
              className="inline-flex items-center gap-2 bg-islamic-100 text-islamic-700 dark:bg-islamic-900/50 dark:text-islamic-300 px-6 py-3 rounded-full font-medium hover:bg-islamic-200 transition-colors"
            >
              <Plus size={18} /> Add Your First Adhkar
            </button>
          </div>
        ) : (
          activeAdhkar.map((item) => {
            const isComplete = item.currentCount === item.count;
            const progress = (item.currentCount / item.count) * 100;
            const isNotified = adhkarNotifications.includes(item.id);

            return (
              <div 
                key={item.id} 
                className={`bg-white dark:bg-slate-800 rounded-3xl p-6 md:p-8 shadow-sm border transition-all relative overflow-hidden group
                  ${isComplete ? 'border-islamic-500 bg-islamic-50/50 dark:bg-islamic-900/10' : 'border-slate-100 dark:border-slate-700'}`}
              >
                {/* Progress Background */}
                <div 
                  className="absolute bottom-0 start-0 h-1 bg-islamic-500 transition-all duration-300"
                  style={{ width: `${progress}%` }}
                ></div>

                {/* Top Actions */}
                <div className="absolute top-4 end-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => {
                      if (!notificationsEnabled) {
                        alert("Please enable notifications in your Profile settings first.");
                        return;
                      }
                      toggleAdhkarNotification(item.id);
                    }}
                    className={`p-2 rounded-full transition-colors ${isNotified ? 'text-islamic-500 bg-islamic-50 dark:bg-islamic-900/30' : 'text-slate-400 hover:text-islamic-500 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
                    title={isNotified ? "Disable Daily Reminder" : "Enable Daily Reminder"}
                  >
                    {isNotified ? <Bell size={18} /> : <BellOff size={18} />}
                  </button>

                  {item.id.startsWith('adhkar_') && (
                    <button 
                      onClick={() => handleDeleteAdhkar(item.id)}
                      className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                      title="Delete Adhkar"
                    >
                      <Trash2 size={18} />
                    </button>
                  )}
                </div>

                <p className="font-arabic text-2xl md:text-3xl leading-loose text-slate-900 dark:text-white mb-6 text-center mt-4" dir="rtl">
                  {item.arabic}
                </p>
                {item.translation && (
                  <p className="text-slate-600 dark:text-slate-400 text-center mb-8">
                    {item.translation}
                  </p>
                )}

                <div className="flex flex-col items-center gap-4">
                  <button
                    onClick={() => handleCount(item.id)}
                    disabled={isComplete}
                    className={`w-24 h-24 rounded-full flex items-center justify-center text-3xl font-bold shadow-lg transition-transform active:scale-95
                      ${isComplete 
                        ? 'bg-islamic-500 text-white cursor-default' 
                        : 'bg-white dark:bg-slate-700 text-islamic-600 dark:text-islamic-400 border-4 border-islamic-100 dark:border-islamic-900 hover:border-islamic-200'}`}
                  >
                    {isComplete ? <CheckCircle2 size={40} /> : item.currentCount}
                  </button>
                  
                  <div className="flex items-center gap-4 text-sm font-medium">
                    <span className="text-slate-500">Target: {item.count}</span>
                    {item.currentCount > 0 && !isComplete && (
                      <button onClick={() => resetCount(item.id)} className="text-red-500 hover:underline">Reset</button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add Category Modal */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-xl">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">New Category</h3>
              <button onClick={() => setIsCategoryModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={20}/></button>
            </div>
            <input
              type="text"
              value={newCategoryName}
              onChange={e => setNewCategoryName(e.target.value)}
              placeholder="Category Name (e.g. After Prayer)"
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 mb-6 focus:outline-none focus:ring-2 focus:ring-islamic-500"
            />
            <button
              onClick={handleAddCategory}
              className="w-full bg-islamic-600 text-white font-bold py-3 rounded-xl hover:bg-islamic-700 transition-colors"
            >
              Create Category
            </button>
          </div>
        </div>
      )}

      {/* Add Adhkar Modal */}
      {isAdhkarModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 w-full max-w-md shadow-xl">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">Add Custom Adhkar</h3>
              <button onClick={() => setIsAdhkarModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={20}/></button>
            </div>
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Arabic Text</label>
                <textarea
                  value={newAdhkarArabic}
                  onChange={e => setNewAdhkarArabic(e.target.value)}
                  dir="rtl"
                  placeholder="Enter Arabic text here..."
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-islamic-500 font-arabic text-lg"
                  rows={3}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Translation / Meaning (Optional)</label>
                <textarea
                  value={newAdhkarTranslation}
                  onChange={e => setNewAdhkarTranslation(e.target.value)}
                  placeholder="Enter translation..."
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-islamic-500"
                  rows={2}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-500 mb-1">Target Count</label>
                <input
                  type="number"
                  min="1"
                  value={newAdhkarCount}
                  onChange={e => setNewAdhkarCount(parseInt(e.target.value) || 1)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-islamic-500"
                />
              </div>
            </div>
            <button
              onClick={handleAddAdhkar}
              className="w-full bg-islamic-600 text-white font-bold py-3 rounded-xl hover:bg-islamic-700 transition-colors"
            >
              Save Adhkar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Adhkar;
