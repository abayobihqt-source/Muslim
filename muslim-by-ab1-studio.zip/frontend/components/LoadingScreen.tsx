import React from 'react';
import { motion } from 'framer-motion';
import { Moon } from 'lucide-react';

const LoadingScreen: React.FC = () => {
  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#022c22] text-white overflow-hidden"
    >
      {/* Premium Background Pattern */}
      <div className="absolute inset-0 opacity-20 bg-[url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23fbbf24\' fill-opacity=\'1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]"></div>
      
      {/* Animated Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-tr from-[#022c22] via-transparent to-[#064e3b] opacity-80"></div>

      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="relative z-10 flex flex-col items-center"
      >
        <div className="relative w-40 h-40 mb-10 flex items-center justify-center">
          {/* Outer rotating ring */}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 border-[3px] border-gold-500/20 rounded-full border-t-gold-400 border-r-gold-400 shadow-[0_0_30px_rgba(251,191,36,0.2)]"
          ></motion.div>
          
          {/* Inner rotating ring */}
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="absolute inset-4 border-[3px] border-islamic-400/20 rounded-full border-b-islamic-400 border-l-islamic-400"
          ></motion.div>
          
          {/* Center Icon */}
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="bg-gradient-to-br from-islamic-300 to-islamic-600 p-4 rounded-full shadow-lg shadow-islamic-500/30"
          >
            <Moon size={48} className="text-white" fill="currentColor" />
          </motion.div>
        </div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="text-5xl font-bold tracking-widest mb-4 font-sans text-transparent bg-clip-text bg-gradient-to-r from-gold-200 via-gold-400 to-gold-200"
        >
          MUSLIM
        </motion.h1>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 1 }}
          className="flex flex-col items-center gap-2"
        >
          <div className="h-px w-12 bg-gradient-to-r from-transparent via-gold-500/50 to-transparent"></div>
          <p className="text-gold-200/70 text-xs tracking-[0.3em] uppercase font-medium">
            Premium Experience
          </p>
          <p className="text-islamic-200/50 text-[10px] tracking-widest uppercase mt-4">
            Crafted by <span className="text-gold-400/80 font-bold">AB1 Studio</span>
          </p>
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default LoadingScreen;
