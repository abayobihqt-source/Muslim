import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Moon, Sun, Globe, Menu, X, Home, BookOpen, Timer, Heart, Image as ImageIcon, User as UserIcon, LogOut, MessageSquareText } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS, FOUNDER_EMAIL } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: string;
  setCurrentPage: (page: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, currentPage, setCurrentPage }) => {
  const { language, setLanguage, theme, setTheme, user, login, logout } = useApp();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const t = (key: string) => TRANSLATIONS[key]?.[language] || key;

  const navItems = [
    { id: 'home', icon: Home, label: t('home') },
    { id: 'quran', icon: BookOpen, label: t('quran') },
    { id: 'prayer', icon: Timer, label: t('prayerTimes') },
    { id: 'adhkar', icon: Heart, label: t('adhkar') },
    { id: 'gallery', icon: ImageIcon, label: t('gallery') },
    { id: 'assistant', icon: MessageSquareText, label: t('assistant') },
    { id: 'profile', icon: UserIcon, label: t('profile') },
  ];

  const toggleLanguage = () => setLanguage(language === 'en' ? 'ar' : 'en');
  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');

  return (
    <div className="min-h-screen flex flex-col bg-pattern">
      {/* Navbar */}
      <header className="sticky top-0 z-40 glass border-b border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          {/* Logo */}
          <div 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => setCurrentPage('home')}
          >
            <Moon className="text-islamic-600 dark:text-islamic-400" fill="currentColor" size={28} />
            <span className="text-xl font-bold text-islamic-900 dark:text-white tracking-tight">Muslim</span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`px-3 py-2 rounded-full text-sm font-medium transition-all duration-200 flex items-center gap-2
                  ${currentPage === item.id 
                    ? 'bg-islamic-100 text-islamic-700 dark:bg-islamic-900/50 dark:text-islamic-300' 
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'}`}
              >
                <item.icon size={16} />
                {item.label}
              </button>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button onClick={toggleLanguage} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-300" title="Switch Language">
              <Globe size={20} />
              <span className="sr-only">Switch Language</span>
            </button>
            <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-300" title="Toggle Theme">
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>
            
            {user ? (
              <div className="hidden md:flex items-center gap-2 ms-2 ps-2 border-s border-slate-200 dark:border-slate-700">
                <img src={user.photoURL} alt="Profile" className="w-8 h-8 rounded-full border-2 border-islamic-500" />
                {user.email === FOUNDER_EMAIL && (
                  <span className="bg-gold-400 text-amber-950 text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
                    👑 {t('founder')}
                  </span>
                )}
              </div>
            ) : (
              <button onClick={login} className="hidden md:block ms-2 px-4 py-2 bg-islamic-600 hover:bg-islamic-700 text-white rounded-full text-sm font-medium transition-colors">
                {t('login')}
              </button>
            )}

            {/* Mobile Menu Toggle */}
            <button 
              className="md:hidden p-2 text-slate-600 dark:text-slate-300"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden glass border-b border-slate-200 dark:border-slate-800 overflow-hidden"
          >
            <div className="p-4 flex flex-col gap-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`px-4 py-3 rounded-xl text-start font-medium flex items-center gap-3
                    ${currentPage === item.id 
                      ? 'bg-islamic-100 text-islamic-700 dark:bg-islamic-900/50 dark:text-islamic-300' 
                      : 'text-slate-600 dark:text-slate-300'}`}
                >
                  <item.icon size={20} />
                  {item.label}
                </button>
              ))}
              <div className="h-px bg-slate-200 dark:bg-slate-700 my-2"></div>
              {user ? (
                <button onClick={() => { logout(); setIsMobileMenuOpen(false); }} className="px-4 py-3 rounded-xl text-start font-medium flex items-center gap-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20">
                  <LogOut size={20} />
                  {t('logout')}
                </button>
              ) : (
                <button onClick={() => { login(); setIsMobileMenuOpen(false); }} className="px-4 py-3 rounded-xl text-center font-medium bg-islamic-600 text-white">
                  {t('login')}
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 py-8 mt-auto">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Moon className="text-islamic-600" fill="currentColor" size={24} />
            <span className="text-lg font-bold text-slate-900 dark:text-white">Muslim</span>
          </div>
          
          <p className="text-slate-500 dark:text-slate-400 text-sm text-center">
            {t('madeWithLove')} <br className="md:hidden" />
            &copy; 2026 <span className="font-semibold text-islamic-600 dark:text-islamic-400">AB1 Studio</span>
          </p>
          
          <div className="flex gap-4 text-sm text-slate-500 dark:text-slate-400">
            <button onClick={() => setCurrentPage('profile')} className="hover:text-islamic-600 transition-colors">{t('privacyPolicy')}</button>
            <button onClick={() => setCurrentPage('profile')} className="hover:text-islamic-600 transition-colors">{t('termsOfService')}</button>
            <a href="mailto:abayobihqt@gmail.com" className="hover:text-islamic-600 transition-colors">{t('contact')}</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
